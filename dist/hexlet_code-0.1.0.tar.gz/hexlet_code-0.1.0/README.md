### Hexlet tests and linter status:
[![Actions Status](https://github.com/DimonDimasik/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DimonDimasik/python-project-50/actions)

###Example of gendiff
https://asciinema.org/a/kb7we7T6f1kKMGpW4qIjHDnrV
