
<div style="display: flex; justify-content: space-between;">

<a href="https://codeclimate.com/github/DimonDimasik/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/4f22b711b4f8a355fcf6/test_coverage" /></a>


<a href="https://codeclimate.com/github/DimonDimasik/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/4f22b711b4f8a355fcf6/maintainability" /></a>
</div>

<!-- HTML for MD, CSS -->


### Hexlet tests and linter status:
[![Actions Status](https://github.com/DimonDimasik/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DimonDimasik/python-project-50/actions)

### Example of gendiff (json):
[![asciicast](https://asciinema.org/a/RuSg4K1nqHjojE4RdJHIoA4p0.svg)](https://asciinema.org/a/RuSg4K1nqHjojE4RdJHIoA4p0)

### Example of gendiff (yaml):
[![asciicast](https://asciinema.org/a/WvsZrGC05IJkOBMlvhal6GH3T.svg)](https://asciinema.org/a/WvsZrGC05IJkOBMlvhal6GH3T)

### Example of gendiff with nested structures(yaml):
[![asciicast](https://asciinema.org/a/p7R6KKhllxpuRX88SoJHoENGO.svg)](https://asciinema.org/a/p7R6KKhllxpuRX88SoJHoENGO)
