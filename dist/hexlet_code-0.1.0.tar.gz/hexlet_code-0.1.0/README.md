<a href="https://codeclimate.com/github/DimonDimasik/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/4f22b711b4f8a355fcf6/maintainability" /></a>

<a href="https://codeclimate.com/github/DimonDimasik/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/4f22b711b4f8a355fcf6/test_coverage" /></a>

### Hexlet tests and linter status:
[![Actions Status](https://github.com/DimonDimasik/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DimonDimasik/python-project-50/actions)

### Example of gendiff
https://asciinema.org/a/kb7we7T6f1kKMGpW4qIjHDnrV
