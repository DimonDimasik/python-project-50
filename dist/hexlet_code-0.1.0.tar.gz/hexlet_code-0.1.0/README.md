
<div style="display: flex; justify-content: space-between;">

[![Maintainability](https://api.codeclimate.com/v1/badges/4f22b711b4f8a355fcf6/maintainability)](https://codeclimate.com/github/DimonDimasik/python-project-50/maintainability)


<a href="https://codeclimate.com/github/DimonDimasik/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/4f22b711b4f8a355fcf6/maintainability" /></a>
</div>

<!-- HTML for MD, CSS -->


### Hexlet tests and linter status:
[![Actions Status](https://github.com/DimonDimasik/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DimonDimasik/python-project-50/actions)

### Example of gendiff:
[![asciicast](https://asciinema.org/a/kb7we7T6f1kKMGpW4qIjHDnrV.svg)](https://asciinema.org/a/kb7we7T6f1kKMGpW4qIjHDnrV)

