#!/usr/bin/env python3
import argparse
from gendiff.modules.parser import parse


def main():
    parse()


if __name__ == '__main__':
    main()
